module.exports = {
	fahrenheitToCelsius: function (value) {
	},
	celsiusToFahrenheit: function (value) {
	},
	mphToKmh: function (value) {
	},
	kmhToMph: function (value) {
	}
};
