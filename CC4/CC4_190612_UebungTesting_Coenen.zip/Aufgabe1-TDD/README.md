Write your own code TDD Style!
==============================

In this case, a number of tests is supplied. There is not yet any JavaScript
code. Please implement the functions one after another. It is a good idea to
start at the top of the failing tests.

Setup
-----

    npm install
    npm install -g mocha

Running
-------

when all the tests pass, run index.js like this:

    node index.js

Running the Tests
-----------------

    mocha
