var assert = require('assert');
var counter = require('../modules/counter');

describe('Counter', function () {
	it.skip('untested', function (done) {
	// ^^^^ remove the "skip" to actually run the test
		done();
	});
});
