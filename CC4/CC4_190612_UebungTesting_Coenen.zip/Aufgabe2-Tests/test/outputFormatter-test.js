var assert = require('assert');
var outputFormatter = require('../modules/outputFormatter');

describe('Output Formatter', function () {
	it.skip('untested', function (done) {
	// ^^^^ remove the "skip" to actually run the test
		done();
	});
});
