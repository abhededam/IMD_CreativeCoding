This is a demo project to introduce you to testing
==================================================

This program will get info off of a website. This is called scraping. It's
a useful technique if a website does not offer a standardized API.

Setup
-----

    npm install
    npm install -g mocha

Running
-------

    node index.js http://demos.claudiuscoenen.de/2016/hda-testing/index.html

Running the Tests
-----------------

    mocha
