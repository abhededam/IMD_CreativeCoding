Temperature-Demo
================

Unit-testing a very simple function

Setup
-----

    npm install
    npm install -g mocha

Running
-------

    node index.js

Running tests
-------------

    mocha
