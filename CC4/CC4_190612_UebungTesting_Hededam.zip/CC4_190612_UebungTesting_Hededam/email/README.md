email-validator-example
=======================

In this example we have a well-tested email regex - or do we?

Actually it has a few shortcomings, see if you can spot them.

Try adding various valid and invalid email addresses to the tests.

Run the tests
-------------

    mocha
