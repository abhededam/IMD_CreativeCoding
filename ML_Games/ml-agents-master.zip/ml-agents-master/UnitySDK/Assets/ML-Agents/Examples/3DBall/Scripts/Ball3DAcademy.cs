﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MLAgents;

public class Ball3DAcademy : Academy
{
    public override void AcademyReset()
    {

    }

    public override void AcademyStep()
    {

    }
}
