﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MLAgents;

public class TemplateAgent : Agent {



    public override void CollectObservations()
    {

    }

    public override void AgentAction(float[] vectorAction, string textAction)
	{

    }

    public override void AgentReset()
    {

    }

    public override void AgentOnDone()
    {

    }
}
