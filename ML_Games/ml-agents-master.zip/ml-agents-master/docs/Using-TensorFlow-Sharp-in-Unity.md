# Using TensorFlowSharp in Unity

As of version 0.7.0, we have included our own Inference Engine as a replacement for TFS.  Please refer to the [release notes](https://github.com/Unity-Technologies/ml-agents/releases/tag/0.7.0)  and [Unity Inference Engine documentation](Unity-Inference-Engine.md)

